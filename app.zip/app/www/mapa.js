/* global browser */

$('#map').click(function() { if ("#panel2b") { browser.navigate = "index.html"; } else { browser.navigate = "paPiso 7.htmlge2.php"; } });


    
  