<?php
 $servidor="172.17.32.100";
 $usuario="catalogo";
 $contrasena="Catalogo$2016"
 $BD="catalogo"
$conexiom=@mysql_connect($servidor,$usuario,$contrasena);
 if (!conexion) {
 	   die( '<strong>no pudo conectarse:</strong>' . mysql_error($conexion));
 	} else{
 		echo "si se conecto";
 	}
  mysql_select_db($catalogo,$conexion) or die(mysql_error($conexion));

  ?>